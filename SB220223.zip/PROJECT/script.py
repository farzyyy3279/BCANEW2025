import tkinter as tk
from tkinter import filedialog, messagebox
import wave
import os
from PIL import Image

def hide_image_in_audio(audio_path, image_path, output_path):
    try:
        # Open the audio file
        audio = wave.open(audio_path, 'rb')
        frame_bytes = bytearray(list(audio.readframes(audio.getnframes())))

        # Open and read the image file
        with open(image_path, 'rb') as img_file:
            img_data = img_file.read()

        # Append delimiter to the image data
        img_data += b'###'

        # Convert image data to binary
        bits = list(map(int, ''.join([bin(byte).lstrip('0b').rjust(8, '0') for byte in img_data])))

        # Replace LSB of each audio byte with image data bits
        for i, bit in enumerate(bits):
            frame_bytes[i] = (frame_bytes[i] & 254) | bit

        # Save the modified audio to a new file
        with wave.open(output_path, 'wb') as output_audio:
            output_audio.setparams(audio.getparams())
            output_audio.writeframes(bytes(frame_bytes))

        audio.close()
        messagebox.showinfo("Success", "Image hidden in audio successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def extract_image_from_audio(audio_path, output_image_path):
    try:
        # Open the audio file
        audio = wave.open(audio_path, 'rb')
        frame_bytes = bytearray(list(audio.readframes(audio.getnframes())))

        # Extract LSBs to reconstruct the image data
        bits = [frame_bytes[i] & 1 for i in range(len(frame_bytes))]
        byte_data = bytearray()
        
        for i in range(0, len(bits), 8):
            byte = int(''.join(map(str, bits[i:i+8])), 2)
            byte_data.append(byte)
            if byte_data[-3:] == b'###':  # Check for delimiter
                byte_data = byte_data[:-3]
                break

        # Write the extracted image data to a file
        with open(output_image_path, 'wb') as img_file:
            img_file.write(byte_data)

        audio.close()
        messagebox.showinfo("Success", "Image extracted from audio successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def browse_audio():
    return filedialog.askopenfilename(filetypes=[("Audio Files", "*.wav")])

def browse_image():
    return filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])

def save_audio():
    return filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("Audio Files", "*.wav")])

def save_image():
    return filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("Image Files", "*.png")])

# GUI Setup
root = tk.Tk()
root.title("Audio Steganography")

# Hide Image in Audio Section
tk.Label(root, text="Hide Image in Audio").grid(row=0, column=0, columnspan=2)

tk.Button(root, text="Select Audio File", command=lambda: hide_audio_entry.insert(0, browse_audio())).grid(row=1, column=0)
hide_audio_entry = tk.Entry(root, width=50)
hide_audio_entry.grid(row=1, column=1)

tk.Button(root, text="Select Image File", command=lambda: hide_image_entry.insert(0, browse_image())).grid(row=2, column=0)
hide_image_entry = tk.Entry(root, width=50)
hide_image_entry.grid(row=2, column=1)

tk.Button(root, text="Save Output Audio As", command=lambda: hide_output_entry.insert(0, save_audio())).grid(row=3, column=0)
hide_output_entry = tk.Entry(root, width=50)
hide_output_entry.grid(row=3, column=1)

tk.Button(root, text="Hide Image", command=lambda: hide_image_in_audio(
    hide_audio_entry.get(), hide_image_entry.get(), hide_output_entry.get())).grid(row=4, column=0, columnspan=2)

# Extract Image from Audio Section
tk.Label(root, text="Extract Image from Audio").grid(row=5, column=0, columnspan=2)

tk.Button(root, text="Select Audio File", command=lambda: extract_audio_entry.insert(0, browse_audio())).grid(row=6, column=0)
extract_audio_entry = tk.Entry(root, width=50)
extract_audio_entry.grid(row=6, column=1)

tk.Button(root, text="Save Extracted Image As", command=lambda: extract_output_entry.insert(0, save_image())).grid(row=7, column=0)
extract_output_entry = tk.Entry(root, width=50)
extract_output_entry.grid(row=7, column=1)

tk.Button(root, text="Extract Image", command=lambda: extract_image_from_audio(
    extract_audio_entry.get(), extract_output_entry.get())).grid(row=8, column=0, columnspan=2)

root.mainloop()
